﻿using System.Windows;

namespace MUS2.UI {

  public partial class App : Application {
  }
}
